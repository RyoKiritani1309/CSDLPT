package guiform;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class DataModel {
    // CẤU HÌNH IP
    public static final String SERVER_IP = "localhost"; 
    
    private String currentRole;
    private String baseUrl;

    public DataModel(String role) {
        this.currentRole = role;
        this.baseUrl = "http://" + SERVER_IP + ":5000/api/"; 
    }
    
    public String getRole() { return currentRole; }

    // --- CẢI TIẾN HÀM GỬI REQUEST ---
    public String sendGetRequest(String endpoint) throws Exception {
        try {
            URL url = new URL(baseUrl + endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000); // 3 giây không thấy API thì báo lỗi mạng
            
            int code = conn.getResponseCode();
            
            if (code == 200) {
                // Đọc dữ liệu thành công
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) response.append(inputLine);
                in.close();
                return response.toString();
            } else {
                // Đọc lỗi từ Server trả về (Ví dụ: Server báo "Lỗi kết nối Site 1")
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                StringBuilder errorMsg = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) errorMsg.append(inputLine);
                in.close();
                throw new Exception(errorMsg.toString()); 
            }
        } catch (java.net.ConnectException e) {
            throw new Exception("API_DOWN"); // Lỗi không thấy Server API (Visual Studio tắt)
        }
    }

    // (Giữ nguyên các hàm sendPostRequest và getList, getKhoa, getDiem cũ...)
    public String sendPostRequest(String endpoint, JSONObject jsonData) throws Exception {
        // ... (Giữ nguyên code cũ)
        URL url = new URL(baseUrl + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; utf-8");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.toString().getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        if (conn.getResponseCode() == 200) return "Thành công!";
        else throw new Exception("Lỗi Server");
    }

    public JSONArray getList(String type) throws Exception {
        String json = sendGetRequest(type + "/getall?role=" + currentRole);
        return new JSONArray(json);
    }
    
    public String getKhoa(String mssv) throws Exception {
        String json = sendGetRequest("sinhvien/getall?role=0");
        JSONArray arr = new JSONArray(json);
        for(int i=0; i<arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            if(obj.getString("MSSV").equalsIgnoreCase(mssv)) 
                return obj.getString("Khoa");
        }
        return "Không tìm thấy";
    }

    public JSONArray getDiem(String mssv) throws Exception {
        String json = sendGetRequest("dangky/getdiem?mssv=" + mssv);
        return new JSONArray(json);
    }
}