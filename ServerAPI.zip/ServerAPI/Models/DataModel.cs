﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServerAPI.Models
{
    // Class đại diện cho Sinh Viên (Dùng cho API GetAll và Add)
    public class SinhVien
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public string Phai { get; set; }
        public DateTime? NgaySinh { get; set; }
        public string MaLop { get; set; }
        public double? HocBong { get; set; }

        // Các thuộc tính bổ sung để hiển thị tên lớp và khoa
        public string TenLop { get; set; }
        public string Khoa { get; set; }
    }

    // Class đại diện cho Đăng Ký (Dùng cho API GetDiem - Câu 2)
    public class DangKy
    {
        public string MSSV { get; set; }
        public string MSMon { get; set; }
        public double? Diem1 { get; set; } // Mảnh A (Site 1)
        public double? Diem2 { get; set; } // Mảnh B (Site 2)
        public double? Diem3 { get; set; } // Mảnh B (Site 2)
    }

    // Class đại diện cho Lớp (Nếu cần dùng cho ComboBox chọn lớp)
    public class Lop
    {
        public string MaLop { get; set; }
        public string TenLop { get; set; }
        public string Khoa { get; set; }
    }
}