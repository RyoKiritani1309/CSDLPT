﻿using ServerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServerAPI.Controllers
{
	[RoutePrefix("api/nganhhoc")]
	public class NganhHocController : ApiController
	{
		private DataModel db = new DataModel();

		// Yêu cầu 5: "DanhSachChuyenNganh" (Đã sửa lỗi)
		[HttpGet]
		[Route("danhsach")]
		public IHttpActionResult DanhSachChuyenNganh()
		{
			// Trong CSDL mới, bảng NGANHHOC được nhân bản (replicated).
			// Chúng ta không cần JOIN các mảnh ..._1 và ..._2 nữa.
			// Chỉ cần truy vấn thẳng vào bảng NGANHHOC (nội bộ).
			string sql = "SELECT * FROM NGANHHOC";
			return Json(db.get(sql));
		}

		// Hàm gọi SP đơn giản
		[HttpGet]
		[Route("toancuc")]
		public IHttpActionResult GetDuLieuToanCuc()
		{
			// SP này cũng truy vấn bảng NGANHHOC nội bộ
			return Json(db.get("EXEC DULIEU_NGANHHOC"));
		}
	}
}
