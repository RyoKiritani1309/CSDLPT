﻿using ServerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServerAPI.Controllers
{
	[RoutePrefix("api/truonghoc")]
	public class TruongHocController : ApiController
	{
		private DataModel db = new DataModel();

		// Yêu cầu 1: "Danh Sach Truong" (Chỉ trả về mảnh nó có)
		[HttpGet]
		[Route("danhsachtruong")]
		public IHttpActionResult DanhSachTruong()
		{
			// Không còn UNION. Chỉ truy vấn bảng TRUONGHOC nội bộ.
			string sql = "SELECT * FROM TRUONGHOC";
			return Json(db.get(sql));
		}

		// Hàm gọi SP đơn giản
		[HttpGet]
		[Route("toancuc")]
		public IHttpActionResult GetDuLieuToanCuc()
		{
			// SP này vẫn truy vấn bảng TRUONGHOC nội bộ
			return Json(db.get("EXEC DULIEU_TRUONGHOC"));
		}
	}
}
