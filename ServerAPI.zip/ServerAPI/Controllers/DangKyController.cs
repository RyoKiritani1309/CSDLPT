﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Http;
using System.Configuration;
using ServerAPI.Models;

namespace ServerAPI.Controllers
{
    public class DangKyController : ApiController
    {
        private string GetConnString() => ConfigurationManager.ConnectionStrings["QLDSV_Tong"].ConnectionString;

        // CÂU 2: Nhập MSSV -> Trả về 3 cột điểm (Tự động Join từ 2 site)
        [HttpGet]
        [Route("api/dangky/getdiem")]
        public IHttpActionResult GetDiem(string mssv)
        {
            var list = new List<DangKy>();
            // Query từ VIEW v_DangKy (Đã Join 2 mảnh dọc A và B)
            string query = "SELECT * FROM v_DangKy WHERE MSSV = @mssv";

            using (SqlConnection conn = new SqlConnection(GetConnString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@mssv", mssv);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    list.Add(new DangKy
                    {
                        MSSV = dr["MSSV"].ToString(),
                        MSMon = dr["MSMON"].ToString(),
                        Diem1 = dr["DIEM1"] != DBNull.Value ? Convert.ToDouble(dr["DIEM1"]) : 0,
                        Diem2 = dr["DIEM2"] != DBNull.Value ? Convert.ToDouble(dr["DIEM2"]) : 0,
                        Diem3 = dr["DIEM3"] != DBNull.Value ? Convert.ToDouble(dr["DIEM3"]) : 0
                    });
                }
            }
            return Ok(list);
        }

        [HttpGet]
        [Route("api/dangky/getall")]
        public IHttpActionResult GetAll(string role = "0")
        {
            // Logic trả về bảng Đăng Ký thô (Raw)
            var list = new List<DangKy>();
            string query = "";

            if (role == "0")
                query = "SELECT MSSV, MSMON, DIEM1, DIEM2, DIEM3 FROM v_DangKy"; // Xem hết
            else if (role == "1")
                query = "SELECT MSSV, MSMON, DIEM1, 0 AS DIEM2, 0 AS DIEM3 FROM DANGKY"; // Site 1 chỉ có diem1
            else if (role == "2")
                query = "SELECT MSSV, MSMON, 0 AS DIEM1, DIEM2, DIEM3 FROM LINK_SITE2.QLDSV_Site2.dbo.DANGKY"; // Site 2 có diem2,3

            // ... (Code kết nối SQL tương tự như trên, map dữ liệu vào list) ...
            // [Phần này bạn tự viết nốt based trên mẫu LopController nhé cho ngắn gọn]
            return Ok(list);
        }
    }
}