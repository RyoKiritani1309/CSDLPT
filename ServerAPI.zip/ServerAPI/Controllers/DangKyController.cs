﻿using ServerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServerAPI.Controllers
{
	[RoutePrefix("api/dangky")]
	public class DangKyController : ApiController
	{
		private DataModel db = new DataModel();

		// Đoạn SQL này không còn UNION. Nó chỉ dùng bảng nội bộ.
		private const string RECONSTRUCT_SQL = @"
            WITH DUHOCSINH_TaiTao AS (
                SELECT * FROM DUHOCSINH
            ),
            TRUONGHOC_TaiTao AS (
                SELECT * FROM TRUONGHOC
            ),
            NGANHHOC_TaiTao AS (
                SELECT * FROM NGANHHOC
            ),
            DANGKY_TaiTao AS (
                SELECT * FROM DANGKY
            )
        ";

		// Yêu cầu 2: "DanhSachDuHocSinhDangKy"
		[HttpGet]
		[Route("dshs_by_truong")]
		public IHttpActionResult GetDHSByTruong([FromUri] string tenTruong)
		{
			string sql = RECONSTRUCT_SQL + $@"
                SELECT DHS.HOTEN, DHS.IELTS, T.TENTRUONG, T.QUOCGIA, DK.TGHOC
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                WHERE T.TENTRUONG LIKE N'%{tenTruong}%';
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 4: "DanhSachTruongDaDangKy"
		[HttpGet]
		[Route("dstruong_by_hs")]
		public IHttpActionResult GetTruongByHS([FromUri] string tenDuHocSinh)
		{
			string sql = RECONSTRUCT_SQL + $@"
                SELECT DHS.HOTEN, DHS.DIEMTB, DHS.IELTS, T.TENTRUONG, N.TENNGANH, DK.TGDANGKY, DK.TGHOC
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE DHS.HOTEN LIKE N'%{tenDuHocSinh}%';
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 6: "DanhSachDuHocSinhDKyChuyenNgang"
		[HttpGet]
		[Route("dshs_by_nganh")]
		public IHttpActionResult GetDHSByNganh([FromUri] string tenChuyenNganh)
		{
			string sql = RECONSTRUCT_SQL + $@"
                SELECT DHS.HOTEN, DHS.DIEMTB, DHS.IELTS AS IELTS_DHS, N.TENNGANH, N.IELTS AS IELTS_Nganh, T.QUOCGIA
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE N.TENNGANH LIKE N'%{tenChuyenNganh}%';
            ";
			return Json(db.get(sql));
		}

		// Hàm gọi SP đơn giản
		[HttpGet]
		[Route("toancuc")]
		public IHttpActionResult GetDuLieuToanCuc() { return Json(db.get("EXEC DULIEU_DANGKY")); }


		// === 5 PHƯƠNG THỨC MỚI (PHẦN THỰC HÀNH) ===
		// (Code 5 hàm này vẫn giữ nguyên như cũ, vì chúng đã dùng RECONSTRUCT_SQL)
		// ... (Dán 5 hàm từ [Route("dshs_by_quocgia")] đến [Route("dshs_hoc_t1_2025")] vào đây) ...

		// Yêu cầu 1:
		[HttpGet]
		[Route("dshs_by_quocgia")]
		public IHttpActionResult GetDHSByQuocGia([FromUri] string quocGia)
		{
			string sql = RECONSTRUCT_SQL + $@"
                SELECT DISTINCT DHS.HOTEN
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                WHERE T.QUOCGIA LIKE N'%{quocGia}%';
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 2:
		[HttpGet]
		[Route("dshs_ielts_thaphon")]
		public IHttpActionResult GetDHS_IELTS_ThapHon()
		{
			string sql = RECONSTRUCT_SQL + @"
                SELECT DHS.HOTEN, DHS.IELTS AS IELTS_DHS, N.TENNGANH, N.IELTS AS IELTS_Nganh
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE DHS.IELTS < N.IELTS;
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 3:
		[HttpGet]
		[Route("dshs_nganh_3nam")]
		public IHttpActionResult GetDHS_Nganh3Nam()
		{
			string sql = RECONSTRUCT_SQL + @"
                SELECT DHS.HOTEN, T.TENTRUONG, N.TENNGANH, N.SONAM
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE N.SONAM = 3;
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 4:
		[HttpGet]
		[Route("dshs_hoc_t9_2024")]
		public IHttpActionResult GetDHS_HocT9_2024()
		{
			string sql = RECONSTRUCT_SQL + @"
                SELECT DHS.HOTEN, T.TENTRUONG, N.TENNGANH, DK.TGHOC
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN TRUONGHOC_TaiTao T ON DK.MATR = T.MATR
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE MONTH(DK.TGHOC) = 9 AND YEAR(DK.TGHOC) = 2024;
            ";
			return Json(db.get(sql));
		}

		// Yêu cầu 5:
		[HttpGet]
		[Route("dshs_hoc_t1_2025")]
		public IHttpActionResult GetDHS_HocT1_2025()
		{
			string sql = RECONSTRUCT_SQL + @"
                SELECT DHS.HOTEN, N.TENNGANH, DK.TGHOC
                FROM DUHOCSINH_TaiTao DHS
                JOIN DANGKY_TaiTao DK ON DHS.MADHS = DK.MADHS
                JOIN NGANHHOC_TaiTao N ON DK.MANG = N.MANG
                WHERE MONTH(DK.TGHOC) = 1 AND YEAR(DK.TGHOC) = 2025;
            ";
			return Json(db.get(sql));
		}
	}
}
