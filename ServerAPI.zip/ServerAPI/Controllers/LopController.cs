﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Http;
using System.Configuration;
using ServerAPI.Models;

namespace ServerAPI.Controllers
{
    public class LopController : ApiController
    {
        private string GetConnString(string role)
        {
            return role == "0"
                ? ConfigurationManager.ConnectionStrings["QLDSV_Tong"].ConnectionString
                : ConfigurationManager.ConnectionStrings["QLDSV_Site1"].ConnectionString; // Site 1 hoặc 2 tùy cấu hình
        }

        [HttpGet]
        [Route("api/lop/getall")]
        public IHttpActionResult GetAll(string role = "0")
        {
            var list = new List<Lop>();
            string query = "";

            // Site 0: Xem View Tổng (Đã Union). Site 1/2: Xem bảng gốc local
            if (role == "0") query = "SELECT * FROM v_Lop";
            else query = "SELECT * FROM LOP"; // Ở Site 1/2 bảng tên là LOP

            // Lưu ý: Site 2 gọi API này với role=2 thì controller SinhVien đã xử lý hướng chuỗi kết nối rồi
            // Để đơn giản, ta dùng logic tương tự SinhVienController cho chuỗi kết nối
            string connStr = ConfigurationManager.ConnectionStrings["QLDSV_Tong"].ConnectionString;
            if (role == "1") connStr = ConfigurationManager.ConnectionStrings["QLDSV_Site1"].ConnectionString;
            // Site 2 sẽ dùng Linked Server qua Site 0 hoặc kết nối trực tiếp nếu bạn cấu hình riêng. 
            // Ở đây ta dùng Site 0 điều phối cho đơn giản.
            if (role == "2") query = "SELECT * FROM LINK_SITE2.QLDSV_Site2.dbo.LOP";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    list.Add(new Lop
                    {
                        MaLop = dr["MALOP"].ToString(),
                        TenLop = dr["TENLOP"].ToString(),
                        Khoa = dr["KHOA"].ToString()
                    });
                }
            }
            return Ok(list);
        }
    }
}