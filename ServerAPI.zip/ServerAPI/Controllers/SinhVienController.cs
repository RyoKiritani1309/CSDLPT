﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Http;
using System.Configuration;
using ServerAPI.Models;

namespace ServerAPI.Controllers
{
    public class SinhVienController : ApiController
    {
        // Lấy chuỗi kết nối: Luôn dùng kết nối Tổng để tận dụng Linked Server
        private string GetConnString()
        {
            return ConfigurationManager.ConnectionStrings["QLDSV_Tong"].ConnectionString;
        }

        // API GET: Lấy danh sách theo Role (0=Tổng, 1=Site1, 2=Site2)
        [HttpGet]
        [Route("api/sinhvien/getall")]
        public IHttpActionResult GetAll(string role = "0")
        {
            var list = new List<SinhVien>();
            string query = "";

            // LOGIC PHÂN QUYỀN DỮ LIỆU:
            if (role == "0") // Site 0: Xem TOÀN BỘ (Qua View Union)
                query = "SELECT sv.*, l.TENLOP, l.KHOA FROM v_SinhVien sv JOIN v_Lop l ON sv.MALOP = l.MALOP";

            else if (role == "1") // Site 1: Xem Local (Bảng gốc Site 1)
                query = "SELECT sv.*, l.TENLOP, l.KHOA FROM LINK_SITE1.QLDSV_Site1.dbo.SINHVIEN sv JOIN LINK_SITE1.QLDSV_Site1.dbo.LOP l ON sv.MALOP = l.MALOP";

            else if (role == "2") // Site 2: Xem Remote (Qua Linked Server trỏ tới Mac)
                query = "SELECT sv.*, l.TENLOP, l.KHOA FROM LINK_SITE2.QLDSV_Site2.dbo.SINHVIEN sv JOIN LINK_SITE2.QLDSV_Site2.dbo.LOP l ON sv.MALOP = l.MALOP";

            try
            {
                using (SqlConnection conn = new SqlConnection(GetConnString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        list.Add(new SinhVien
                        {
                            MSSV = dr["MSSV"].ToString(),
                            HoTen = dr["HOTEN"].ToString(),
                            MaLop = dr["MALOP"].ToString(),
                            TenLop = dr["TENLOP"].ToString(),
                            Khoa = dr["KHOA"].ToString(),
                            HocBong = dr["HOCBONG"] != DBNull.Value ? Convert.ToDouble(dr["HOCBONG"]) : 0
                        });
                    }
                }
                return Ok(list);
            }
            catch (Exception ex) { return BadRequest("Lỗi Server: " + ex.Message); }
        }

        // API ADD: Thêm mới (Tự động điều hướng sang Site 1 hoặc Site 2)
        [HttpPost]
        [Route("api/sinhvien/add")]
        public IHttpActionResult AddSinhVien(SinhVien sv)
        {
            using (SqlConnection conn = new SqlConnection(GetConnString()))
            {
                conn.Open();

                // B1: Kiểm tra xem Mã Lớp thuộc Khoa nào?
                // (Lưu ý: View v_Lop đã Union cả 2 site nên tra ở đây là thấy hết)
                string checkKhoaQuery = "SELECT KHOA FROM v_Lop WHERE MALOP = @malop";
                SqlCommand cmdCheck = new SqlCommand(checkKhoaQuery, conn);
                cmdCheck.Parameters.AddWithValue("@malop", sv.MaLop);
                var khoaObj = cmdCheck.ExecuteScalar();

                if (khoaObj == null) return BadRequest("Mã lớp không tồn tại trong hệ thống!");
                string khoa = khoaObj.ToString().Trim();

                // B2: Điều hướng INSERT (Transparency - Trong suốt phân tán)
                string insertQuery = "";
                if (khoa == "K1") // Thuộc Site 1
                {
                    insertQuery = @"INSERT INTO LINK_SITE1.QLDSV_Site1.dbo.SINHVIEN 
                                    (MSSV, HOTEN, PHAI, NGAYSINH, MALOP, HOCBONG) 
                                    VALUES (@mssv, @hoten, @phai, @ngaysinh, @malop, @hocbong)";
                }
                else if (khoa == "K2") // Thuộc Site 2 (Máy Mac)
                {
                    insertQuery = @"INSERT INTO LINK_SITE2.QLDSV_Site2.dbo.SINHVIEN 
                                    (MSSV, HOTEN, PHAI, NGAYSINH, MALOP, HOCBONG) 
                                    VALUES (@mssv, @hoten, @phai, @ngaysinh, @malop, @hocbong)";
                }

                SqlCommand cmdInsert = new SqlCommand(insertQuery, conn);
                cmdInsert.Parameters.AddWithValue("@mssv", sv.MSSV);
                cmdInsert.Parameters.AddWithValue("@hoten", sv.HoTen);
                cmdInsert.Parameters.AddWithValue("@phai", sv.Phai ?? "Nam");
                cmdInsert.Parameters.AddWithValue("@ngaysinh", sv.NgaySinh ?? DateTime.Now);
                cmdInsert.Parameters.AddWithValue("@malop", sv.MaLop);
                cmdInsert.Parameters.AddWithValue("@hocbong", sv.HocBong ?? 0);

                try
                {
                    cmdInsert.ExecuteNonQuery();
                    return Ok("Đã thêm thành công vào Khoa " + khoa);
                }
                catch (Exception ex)
                {
                    return BadRequest("Lỗi thêm mới: " + ex.Message);
                }
            }
        }
    }
}