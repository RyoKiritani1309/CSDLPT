﻿using ServerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServerAPI.Controllers
{
	[RoutePrefix("api/duhocsinh")]
	public class DuHocSinhController : ApiController
	{
		private DataModel db = new DataModel();

		// Yêu cầu 3: "DanhSachDuHocSinh" (Được nhân bản)
		[HttpGet]
		[Route("danhsach")]
		public IHttpActionResult DanhSachDuHocSinh()
		{
			// Bảng này được nhân bản nên chỉ cần SELECT *
			string sql = "SELECT * FROM DUHOCSINH";
			return Json(db.get(sql));
		}

		// Hàm gọi SP đơn giản
		[HttpGet]
		[Route("toancuc")]
		public IHttpActionResult GetDuLieuToanCuc()
		{
			return Json(db.get("EXEC DULIEU_DUHOCSINH"));
		}
	}
}
